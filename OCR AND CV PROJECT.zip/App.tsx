
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import AnalysisDashboard from './components/AnalysisDashboard';
import { analyzeImage } from './services/geminiService';
import { AnalysisResult, AppStatus } from './types';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageSelect = useCallback(async (base64: string) => {
    setImagePreview(base64);
    setStatus(AppStatus.LOADING);
    setError(null);
    setResult(null);

    try {
      const analysisResult = await analyzeImage(base64);
      setResult(analysisResult);
      setStatus(AppStatus.SUCCESS);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during analysis.");
      setStatus(AppStatus.ERROR);
    }
  }, []);

  const reset = () => {
    setStatus(AppStatus.IDLE);
    setError(null);
    setResult(null);
    setImagePreview(null);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full">
        {status === AppStatus.IDLE && (
          <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-top-4 duration-500">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-slate-900 sm:text-4xl">
                Transform Handwriting into Digital Text
              </h2>
              <p className="mt-4 text-lg text-slate-600">
                Upload your handwritten notes, medical prescriptions, or scanned documents. 
                Our AI extracts text with 99%+ accuracy and corrects errors instantly.
              </p>
            </div>
            <ImageUploader onImageSelect={handleImageSelect} isLoading={false} />
          </div>
        )}

        {status === AppStatus.LOADING && (
          <div className="flex flex-col items-center justify-center py-20 space-y-6">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-8 h-8 bg-indigo-600 rounded-full animate-pulse"></div>
              </div>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-bold text-slate-900">Analyzing Your Document...</h3>
              <p className="text-slate-500 mt-2">Running high-precision OCR and linguistic correction models.</p>
              <div className="mt-8 flex space-x-1 justify-center">
                <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></span>
              </div>
            </div>
          </div>
        )}

        {status === AppStatus.ERROR && (
          <div className="max-w-md mx-auto text-center py-10 animate-in zoom-in duration-300">
            <div className="bg-red-50 p-6 rounded-2xl border border-red-100">
              <svg className="w-16 h-16 text-red-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <h3 className="text-lg font-bold text-red-800">Processing Failed</h3>
              <p className="mt-2 text-red-600 text-sm">{error}</p>
              <button 
                onClick={reset}
                className="mt-6 w-full py-3 px-4 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 transition-colors shadow-lg"
              >
                Try Another Image
              </button>
            </div>
          </div>
        )}

        {status === AppStatus.SUCCESS && result && imagePreview && (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Analysis Complete</h2>
                <p className="text-slate-500">Review your extracted content and AI suggestions below.</p>
              </div>
              <button 
                onClick={reset}
                className="px-4 py-2 border border-slate-300 text-slate-600 font-semibold rounded-lg hover:bg-slate-50 transition-colors"
              >
                Start New Scan
              </button>
            </div>
            
            <AnalysisDashboard result={result} imagePreview={imagePreview} />
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-slate-400 text-sm">
          <p>© 2024 PrecisionVision OCR. Powered by Google Gemini 3 Flash.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
