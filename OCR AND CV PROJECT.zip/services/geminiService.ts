
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

export const analyzeImage = async (base64Image: string): Promise<AnalysisResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = `
    Perform a high-precision OCR on the provided image, which may contain handwritten or printed text.
    Your task is divided into three critical parts:
    
    1. EXTRACTED TEXT: Provide the exact transcription of the text in the image. Aim for 99.9% accuracy. Do not change any spelling or grammar in this section, even if they are incorrect in the image.
    2. CORRECTIONS: Identify every single spelling mistake, grammar error, punctuation error, or unclear word. For each error, provide the original text, the corrected version, and the type of error. 
    3. SUGGESTIONS: Provide stylistic or structural improvements to make the text more professional or clearer.
    
    Return the result strictly as a JSON object with the following structure:
    {
      "extractedText": "exact text from image",
      "corrections": [
        { "original": "text", "corrected": "text", "type": "spelling|grammar|unclear|punctuation", "explanation": "why" }
      ],
      "suggestions": ["suggestion 1", "suggestion 2"],
      "accuracyScore": 99.5
    }
    
    Ensure the accuracy score reflects your confidence in the OCR process.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: base64Image.split(',')[1] || base64Image
              }
            }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            extractedText: { type: Type.STRING },
            corrections: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  original: { type: Type.STRING },
                  corrected: { type: Type.STRING },
                  type: { type: Type.STRING },
                  explanation: { type: Type.STRING }
                },
                required: ["original", "corrected", "type"]
              }
            },
            suggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            accuracyScore: { type: Type.NUMBER }
          },
          required: ["extractedText", "corrections", "suggestions", "accuracyScore"]
        }
      }
    });

    const resultText = response.text;
    if (!resultText) throw new Error("No response from AI model.");
    
    return JSON.parse(resultText) as AnalysisResult;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
