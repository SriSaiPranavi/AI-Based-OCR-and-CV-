
import React from 'react';
import { AnalysisResult, Correction } from '../types';

interface AnalysisDashboardProps {
  result: AnalysisResult;
  imagePreview: string;
}

const AnalysisDashboard: React.FC<AnalysisDashboardProps> = ({ result, imagePreview }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Left Column: Image and Extracted Text */}
      <div className="space-y-6">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Original Source</h3>
          </div>
          <div className="p-6 flex justify-center bg-slate-100">
            <img 
              src={imagePreview} 
              alt="Uploaded source" 
              className="max-h-[400px] w-auto rounded-lg shadow-lg object-contain"
            />
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Extracted Text (Raw)</h3>
            <span className="px-2 py-1 bg-green-100 text-green-700 text-[10px] font-black rounded">
              {result.accuracyScore}% ACCURACY
            </span>
          </div>
          <div className="p-6">
            <p className="text-slate-700 leading-relaxed whitespace-pre-wrap font-mono text-sm bg-slate-50 p-4 rounded-xl border border-slate-200">
              {result.extractedText || "No text extracted."}
            </p>
          </div>
        </div>
      </div>

      {/* Right Column: Corrections and Suggestions */}
      <div className="space-y-6">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">AI Corrections</h3>
          </div>
          <div className="p-6">
            {result.corrections.length > 0 ? (
              <div className="space-y-4">
                {result.corrections.map((corr, idx) => (
                  <div key={idx} className="flex items-start space-x-4 p-4 rounded-xl border border-slate-100 bg-white hover:border-indigo-200 transition-colors shadow-sm">
                    <div className={`mt-1 p-2 rounded-lg ${
                      corr.type === 'spelling' ? 'bg-red-50 text-red-600' :
                      corr.type === 'grammar' ? 'bg-blue-50 text-blue-600' :
                      'bg-amber-50 text-amber-600'
                    }`}>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-slate-400 line-through text-sm">{corr.original}</span>
                        <svg className="w-3 h-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                        <span className="text-indigo-600 font-bold text-sm">{corr.corrected}</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1 italic">{corr.explanation}</p>
                      <span className="mt-2 inline-block text-[10px] uppercase font-bold text-slate-400">{corr.type}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10 text-slate-400">
                <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <p className="text-sm font-medium">No errors detected. Perfect writing!</p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 bg-indigo-50/30">
            <h3 className="text-sm font-bold text-indigo-800 uppercase tracking-wider">Smart Suggestions</h3>
          </div>
          <div className="p-6">
            {result.suggestions.length > 0 ? (
              <ul className="space-y-3">
                {result.suggestions.map((sug, idx) => (
                  <li key={idx} className="flex items-start space-x-3 text-sm text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <span className="text-indigo-500 font-bold">•</span>
                    <span>{sug}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-500 italic">No further suggestions.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisDashboard;
