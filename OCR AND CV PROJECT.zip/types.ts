
export interface Correction {
  original: string;
  corrected: string;
  type: 'spelling' | 'grammar' | 'unclear' | 'punctuation';
  explanation: string;
}

export interface AnalysisResult {
  extractedText: string;
  corrections: Correction[];
  suggestions: string[];
  accuracyScore: number;
}

export enum AppStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}
